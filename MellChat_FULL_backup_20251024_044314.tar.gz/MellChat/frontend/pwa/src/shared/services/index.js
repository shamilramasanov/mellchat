export { default as api, authAPI, streamsAPI, emojiAPI, healthAPI } from './api';

